from pyzbar import pyzbar
import time
import cv2
import operator
import threading
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import sqlite3

class Scanner():
    def __init__(self):
        #echo is used for purpose of logging
        # self.engine = create_engine('sqlite:///test.db', echo=False)
        # self.Base = declarative_base()
        # self.Session = sessionmaker(bind=self.engine)()


        pass
    def getScannedResult(self, found):
        self.vs = cv2.VideoCapture(0)
        stop_time = time.time() + 10
        while time.time() < stop_time:
            rect, frame = self.vs.read()
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            barcodes = pyzbar.decode(gray)
            for barcode in barcodes:
                (x, y, w, h) = barcode.rect
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
                barcodeData = barcode.data.decode("utf-8")
                barcodeType = barcode.type
                text = "{} ({})".format(barcodeData, barcodeType)
                cv2.putText(frame, text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
                if barcodeData not in found:
                    found[barcodeData] = 1
                if barcodeData in found:
                    found[barcodeData] += 1
            cv2.imshow("Barcode Scanner", frame)
            key = cv2.waitKey(1) & 0xFF

    def finalResult(self):
        found = dict()
        self.getScannedResult(found)
        # trackingNumber = max(found.items(), key=operator.itemgetter(1))[0]
        # delivery = self.Session.query(Deliveries).filter_by(tracking_number=trackingNumber).first()
        # if not delivery and delivery.status!=1:
        #     return
        # delivery.status = 1
        #
        # import sqlite3
        # conn = None
        # try:os
        #     conn = sqlite3.connect('../test.db')
        # except Error as e:
        #     print(e)
        #     exit()
        # cur = conn.cursor()
        # cur.execute("UPDATE deliveries SET status=1 WHERE delivery_id=1")
        # conn.commit()
        self.vs.release()
        cv2.destroyAllWindows()
        return trackingNumber
x = Scanner()
print(x.finalResult())
